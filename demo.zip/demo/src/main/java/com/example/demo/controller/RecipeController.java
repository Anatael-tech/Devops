package com.example.demo.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

public class RecipeController {

    @FXML
    private Button look;

    @FXML
    private Label recipeLabel;

    @FXML
    private AnchorPane recipePane;


}

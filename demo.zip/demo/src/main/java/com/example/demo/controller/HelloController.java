package com.example.demo.controller;


import com.example.demo.HelloApplication;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private Button btnAddRecipe;

    @FXML
    private Button btnSearchRecipe;

    @FXML
    private Button closeBtn;

    @FXML
    private Pane headerPane;

    @FXML
    private Pane mainPane;

    @FXML
    private TextField recipeTextField;

    @FXML
    private ScrollPane scrollRecipe;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("recipe-view.fxml"));
        try {
            AnchorPane pane = fxmlLoader.load();
            scrollRecipe.setContent(pane);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}


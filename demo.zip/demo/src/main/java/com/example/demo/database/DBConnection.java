package com.example.demo.database;
import java.util.*;
import java.sql.*;

public class DBConnection {

    private Connection connection;


    public DBConnection()
    {
        this.connection = null;
        try
        {
            if (this.connection == null){
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/db_recipes_app","root","irfan");

            }

        }
        catch ( SQLException e )
        {
            e.printStackTrace();
            System.exit(1);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


    }

    public Connection getConnection(){
        return connection;
    }
}

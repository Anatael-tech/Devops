package com.example.demo.database;

import com.example.demo.model.Recipe;

import java.sql.ResultSet;

public class Database {

    private ResultSet result;
    private DBConnection connection;

    public Database(){
        this.connection = new DBConnection();
    }

    public Recipe getRecipe(){
        return null;
    }
}
